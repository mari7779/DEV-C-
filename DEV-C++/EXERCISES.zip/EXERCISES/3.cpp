#include <stdio.h>

int main(){
	float pi = 3.1415;
	printf("%f \n",pi);
}
