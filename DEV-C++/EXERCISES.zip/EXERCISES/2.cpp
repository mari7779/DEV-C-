#include <stdio.h>
 
int main(){
	int A;
	A=2.97;
	printf("%d",A);
}
