#include<math.h>
#include<stdio.h>
	int main(void){
	
