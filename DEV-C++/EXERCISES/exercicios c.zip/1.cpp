#include <stdio.h>

#include <locale.h>

int main(void){
	
	setlocale(LC_ALL, "portuguese");
	printf("Rebeca � a nossa Deusa soberana!");
}
