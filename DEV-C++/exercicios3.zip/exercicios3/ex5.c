#include<stdio.h>
void main()
{
int num1, num2, res;
num1 = 10;
num2 = 0;

if (num2 == 0)
{
printf("impossivel dividir por zero");
}
else{
res = num1/num2;
printf("o resultado e %d\n", res);
}
}
