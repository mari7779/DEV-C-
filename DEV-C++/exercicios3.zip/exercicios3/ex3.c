#include<stdio.h>
int main(void){
int valor = 0 ;
if (valor < 0){printf("Primeira compara��o \n");}
else{printf("Terceira compara��o \n");}
if (valor == 0){printf("Segunda compara��o \n");}
}
