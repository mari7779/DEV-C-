#include<stdio.h>
void main()
{
int valor; //
valor = 1;
if (valor < 0)
{
printf("Primeira compara��o\n");
}
if (valor == 0)
{
printf("Segunda compara��o\n");
}
if (valor > 0);
{
printf("Terceira compara��o\n");
}
}
