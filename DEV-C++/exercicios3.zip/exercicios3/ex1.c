#include<stdio.h>
void main()
{
int valor;
valor = 13;
if (valor == 15)
{
printf("Valor %d!\n", valor);
}
else
{
printf("Resultado do valor %d\n", valor);
}
}

